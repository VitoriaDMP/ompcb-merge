import orjson

def merge_traces(
    ompc_path, ompc_files):
    """
    Merge OMPC and OmpTracing timelines with options to filter and synchronize
    events.
    """
    ompc_evts = []
    min_ts_by_pid = {}

    # Merge events from OMPC traces
    for file in ompc_files:
        local_timeline = orjson.loads(file.read())

        evts = local_timeline["traceEvents"]

        # Synchronize events across timelines
        # Find the smaller timestamp among events
        min_ts = min(evt["ts"] for evt in evts if evt["ph"] == "X")
        # Shift all events timestamp back by the minimum timestamp
        for evt in local_timeline["traceEvents"]:
            if evt["ph"] == "X":
                evt["ts"] = evt["ts"] - min_ts
            min_ts_by_pid[evt["pid"]] = min_ts

        ompc_evts.extend(evts)


    # Return unified timeline containing both OMPC and OMPT events
    return {
        "traceEvents": [
            *ompc_evts,
        ]
    }