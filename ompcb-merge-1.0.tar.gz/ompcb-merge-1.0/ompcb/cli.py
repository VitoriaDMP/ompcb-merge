import os
import click
import orjson
import sys

from pathlib import Path
from contextlib import ExitStack

#from ompcbench import __version__, messages as msg
from ompcb.merge import merge_traces


@click.group()
@click.pass_context
def main(ctx):
    """
    A command-line tool for merge OmpCluster timelines.
    """
    #print("OMPC Bench ")
    pass

@main.command()
#@click.version_option(__version__)
@click.pass_obj
@click.option(
    "-c",
    "--ompc-prefix",
    required=True,
    nargs=1,
    type=str,
    help="OMPC traces prefix.",
)
@click.option(
    "-o",
    "--output",
    default="tracing.json",
    type=click.File("wb"),
    help="Output file name.",
)
def all(ctx, ompc_prefix, output):
    """
    Merge all OMPC traces. 
    """
    #msg.secho(f"OMPC Bench Merge, v{__version__}", bold=True)
    cwd = Path(".")

    with ExitStack() as stack:
        # List of all files that match prefix
        ompc_fnames = list(cwd.glob(f"{ompc_prefix}*.json"))

        # Open files and push to the stack to be cleanup automatically later
        ompc_files = [stack.enter_context(path.open(mode="r")) for path in ompc_fnames]

        # Get OMPC path to find the graph file
        ompc_path = Path(ompc_prefix)
        if not ompc_path.is_dir():
            ompc_path = Path(ompc_path.parent)

        try:
            timeline = merge_traces(
                ompc_path,
                ompc_files,
            )
            output.write(orjson.dumps(timeline))
        except Exception as error:
            print(error)
